<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/8/17
 * Time: 17:26
 */

namespace app\lib\enum;


class ScopeEnum
{
    const USER = 16;
    const SUPER = 32;
}