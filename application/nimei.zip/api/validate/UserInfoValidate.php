<?php
namespace app\api\validate;

class UserInfoValidate extends BaseValidate
{
    protected $rule = [
        'nick_name' => 'require',
        'gender' => 'require|in:0,1,2',
        'city' => 'require',
        'province' => 'require',
        'country' => 'require',
        'avatar_url' => 'require'
    ];

}
