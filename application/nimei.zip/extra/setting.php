<?php
return [
    'token_expire_in' => 7200,
    'img_url_prefix' => 'http://ershou.cn/images'
];