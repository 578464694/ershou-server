<?php
return [
//
    'app_id' => 'wx2fcd4c19ad1c89ac',
    'secret' => '4d94a02a7945d5c46cfa55fffb5c6a76',
    'wx_base_url' => 'https://api.weixin.qq.com/sns/jscode2session?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code'
];