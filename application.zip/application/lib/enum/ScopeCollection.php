<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/9/3
 * Time: 19:28
 */

namespace app\lib\enum;


class ScopeCollection
{
    const COLLECTED = 1;    // 收藏
}