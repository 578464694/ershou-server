<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/8/26
 * Time: 8:24
 */

namespace app\lib\enum;


class StatusEnum
{
    const SALED = 0;
    const NORMAL = 1;
    const DELETE = 2;
}