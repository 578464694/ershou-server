<?php
namespace app\api\model;
use think\Model;

class BaseModel extends Model
{
    protected function prefixUrl($url,$array){
        if(!$url){
            return '';
        }
        else{
            $url = config('setting.img_url_prefix').$url;
            return $url;
        }
    }

    protected function integerConvertToBoolean($value,$data)
    {
        if($value){
            return true;
        }
        else{
            return false;
        }
    }
}