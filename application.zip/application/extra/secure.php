<?php
return [
    'salt' => 'wangnima'
];